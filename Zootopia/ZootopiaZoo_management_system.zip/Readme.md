Project Name: Zootopia
   
The purpose of developing this software is to track of all types of animals and others information of a zoo. 
The system is user friendly and efficient for storing data. It will be helpful for animal conservation by ensuring 
the proper food and medicine supply for the animals. 

To execute our project-
1. First import the sql file and connect it to a database named Zootopia.
2.Execute the sql file.
3.connection code-
    String url="jdbc:sqlserver://localhost:1433;databaseName=Zootopia";
        String username="sa";
        String password="";
            Connection con = DriverManager.getConnection(url,username,password); 
4. Open the project in java and run the home.java file.
5. In home page click start->next after that you have to login with username:Odhora ,password:140600
6. Then the page with all the tables will be shown. By clicking a particular table the insert,update,table show options will be displayed.
7. Information can be added by clicking insert option, information can be updated by clicking update button,and also can be deleted.
   Display option will show all the information about that table.


Created By
1.190204010
2.190204013
3.190204024
4.190204026